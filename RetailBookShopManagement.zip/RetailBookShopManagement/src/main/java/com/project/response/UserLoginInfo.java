/**
 * 
 */
package com.project.response;


public class UserLoginInfo {

}
