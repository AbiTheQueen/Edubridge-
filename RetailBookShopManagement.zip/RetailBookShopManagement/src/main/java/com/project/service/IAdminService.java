package com.project.service;

import java.util.List;

import com.project.entity.Book;



public interface IAdminService {
	

	boolean verifyBook(long bookId, String staus, String token);


	List<Book> getBooksByStatus(String status);


}
