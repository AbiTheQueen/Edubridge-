package com.project.service;

import java.util.List;

import com.project.entity.Order;


public interface OrderService {

	List<Order> getOrderList(String token);

	Order getOrderConfrim(String token);

	int getCountOfBooks(String token);
}
