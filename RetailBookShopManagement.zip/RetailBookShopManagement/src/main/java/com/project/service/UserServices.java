
package com.project.service;

import java.util.List;

import com.project.dto.UserDto;
import com.project.entity.Users;
import com.project.request.LoginInformation;
import com.project.request.PasswordUpdate;



public interface UserServices {

	Users login(LoginInformation information);
	boolean register(UserDto ionformation);
	boolean verify(String token) throws Exception;
	boolean isUserExist(String email);
	boolean update(PasswordUpdate information, String token);
	List<Users> getUsers();
	Users getSingleUser(String token);
}