package com.project.repository;

import java.util.List;

import com.project.entity.Book;



public interface IBook {

	Book save(Book bookinformation);

	List<Book> getUsers();

}
