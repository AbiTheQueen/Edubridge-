package com.project.util;

import org.springframework.stereotype.Component;

@Component
public class RandomNumberGenerator {

}
