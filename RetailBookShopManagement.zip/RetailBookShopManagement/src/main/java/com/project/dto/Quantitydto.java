package com.project.dto;

public class Quantitydto 
{

}
