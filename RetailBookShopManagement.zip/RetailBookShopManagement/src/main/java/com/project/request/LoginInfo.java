
package com.project.request;

public class LoginInfo {

}
