package com.project.servicelayer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.anything;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.project.controller.BookStoreController;
import com.project.controller.CartController;
import com.project.entity.Book;
import com.project.entity.Users;
import com.project.impl.AdminServiceImpl;
import com.project.impl.BookServiceImplementation;
import com.project.impl.CartServiceImplimentation;
import com.project.repository.BookImple;
import com.project.repository.BookInterface;
import com.project.repository.CustomerRepository;
import com.project.util.JwtGenerator;



@RunWith(MockitoJUnitRunner.class)
public class AdminServiceImpleTest {
	
	@InjectMocks
	BookStoreController bookStoreController;
	
	@InjectMocks
	CartController cartController;
	
	@Mock
	BookServiceImplementation bookServiceImplementation;
	
	@Mock
	JwtGenerator jwt;

	@Mock
	BookInterface bookRepo;
	
	@Mock
	CustomerRepository userRepo;
	
	@InjectMocks
	private AdminServiceImpl adminService;
	
	private MockMvc mockMvc;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(adminService).build();
	}
	
	@Mock
	private BookImple repository;
	
	Book info;
	
	@Mock
	CartServiceImplimentation cartService;
	

	
	@Test
	final void verify_Book_Test() {
		String token="validToken";
		long userId=1L;
		Mockito.when(jwt.parseJWT(token)).thenReturn(userId);
		Users user=new Users();
		user.setName("brijesh");
		user.setMobileNumber(7259866545L);
		user.setAddress(null);
		user.setCartBooks(null);
		user.setCreatedDate(null);
		user.setRole("admin");
		
		Mockito.when(userRepo.getCustomerDetailsbyId(userId)).thenReturn(user);
		
		Book book=new Book();
		
		book.setBookName("book1");
		book.setAuthorName("amit");
		book.setBookDetails("Some book");
		book.setImage("sita.jpg");
		book.setNoOfBooks(20L);
		book.setPrice(200.00);
		book.setStatus("OnHold");
		book.setCreatedDateAndTime(null);
		book.setUpdatedDateAndTime(null);
		
		Mockito.when(bookRepo.findByBookId(Mockito.anyLong())).thenReturn(book);
		Mockito.when(bookRepo.save(book)).thenReturn(book);
		
		
		boolean res=adminService.verifyBook(1L,"OnHold",token);
		assertTrue(res==true);
	}
	
	@Test
	final void get_Books_By_Valid_Status_Test() {
		Book book=new Book();
		
		book.setBookName("book1");
		book.setAuthorName("amit");
		book.setBookDetails("Some book");
		book.setImage("sita.jpg");
		book.setNoOfBooks(20L);
		book.setPrice(200.00);
		book.setStatus("OnHold");
		book.setCreatedDateAndTime(null);
		book.setUpdatedDateAndTime(null);
		
		List<Book> actualBookList = new ArrayList<Book>();
		actualBookList.add(book);
		
		Mockito.when(bookRepo.findByStatus("OnHold")).thenReturn(actualBookList);
		
		assertThat(adminService.getBooksByStatus("OnHold")).isEqualTo(actualBookList);

	}
	
	@Test
	final void get_Books_By_InValid_Status_Test() {
		Book book=new Book();
		
		book.setBookName("book1");
		book.setAuthorName("amit");
		book.setBookDetails("Some book");
		book.setImage("sita.jpg");
		book.setNoOfBooks(20L);
		book.setPrice(200.00);
		book.setStatus("OnHold");
		book.setCreatedDateAndTime(null);
		book.setUpdatedDateAndTime(null);
		
		List<Book> actualBookList = new ArrayList<Book>();
		actualBookList.add(book);
		
		Mockito.when(bookRepo.findByStatus("OnHold")).thenReturn(actualBookList);

		assertThat(adminService.getBooksByStatus(Mockito.anyString())).isNotEqualTo(actualBookList);
	}
}
