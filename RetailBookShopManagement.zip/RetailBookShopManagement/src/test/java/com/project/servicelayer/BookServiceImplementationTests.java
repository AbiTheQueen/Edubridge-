package com.project.servicelayer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;

import com.project.dto.BookDto;
import com.project.entity.Book;
import com.project.impl.BookServiceImplementation;
import com.project.impl.CartServiceImplimentation;
import com.project.repository.BookImple;


class BookServiceImplementationTests {

	@InjectMocks
	BookServiceImplementation service;

	@InjectMocks
	CartServiceImplimentation cusservice;
	
	@Mock
	BookDto dto;

	@Mock
	private BookImple repository;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	final void testGetBookbyId() {
		Book info = new Book();
		when(repository.fetchbyId((long) 1)).thenReturn(info);
		Book bookinfo = service.getBookbyId((long) 1);
		assertEquals(info, bookinfo);
	}

	@Test
	final void testPagewise() {
		List<Book> book = new ArrayList<Book>();
		when(repository.findAllPage(PageRequest.of(0, 2))).thenReturn(book);
		List<Book> list = service.findAllPageBySize(0);
		assertEquals(book.size(), list.size());
	}

	@Test
	final void testUnSort() {
		List<Book> book = new ArrayList<Book>();
		when(repository.findAll()).thenReturn(book);
		List<Book> sort = service.sortGetAllBooks();
		assertEquals(sort.size(), book.size());
	}

	@Test
	final void sorting() {
		List<Book> book = new ArrayList<Book>();
		when(repository.findAll()).thenReturn(book);
		List<Book> sort = service.sorting(false);
		assertEquals(sort.size(), book.size());
	}


}
