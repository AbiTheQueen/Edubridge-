package miniproject;

import java.util.Scanner;

 public class CoreJavaMiniProject {
	  public static void main(String[] args) {
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter your Name & CustomerId to access :");
	        String name=sc.nextLine();
	        String customerId=sc.nextLine();
	        BankDetails obj=new  BankDetails(name,customerId);
	        obj.menu();
	    }
	}

	class  BankDetails{
	    double balance;
	    double previousTransaction;
	    String customerName;
	    String customerId;

	    BankDetails(String customerName,String customerId){
	        this.customerName=customerName;
	        this.customerId=customerId;
	    }


	    void deposit(double amount){
	        if(amount!=0){
	            balance+=amount;
	            previousTransaction=amount;
	        }
	    }

	    void withdraw(double amount){
	        if(amount!=0 && balance>=amount){
	            balance-=amount;
	            previousTransaction=-amount;
	        }
	        else if(balance<amount){
	            System.out.println("Insufficient Bank Balance");
	        }
	    }

	    void getPreviousTransaction(){
	        if(previousTransaction>0){
	            System.out.println("Deposited: "+previousTransaction);
	        }
	        else if(previousTransaction<0){
	            System.out.println("Withdrawn: "+Math.abs(previousTransaction));
	        }
	        else{
	            System.out.println("No transaction occured");
	        }
	    }

	    void menu(){
	        char option;
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Welcome "+customerName);
	        System.out.println("Your ID:"+customerId);
	        System.out.println("\n");
	        System.out.println("1) Check Balance");
	        System.out.println("2) Deposit Amount");
	        System.out.println("3) Withdraw Amount");
	        System.out.println("4) Previous Transaction");
	        System.out.println("5) Exit");

	        do{
	            System.out.println("********************************************");
	            System.out.println("Choose an option");
	            option=sc.next().charAt(0);
	            System.out.println("\n");

	            switch (option){
	                case '1':
	                    System.out.println("......................");
	                    System.out.println("Balance ="+balance);
	                    System.out.println("......................");
	                    System.out.println("\n");
	                    break;
	                case '2':
	                    System.out.println("......................");
	                    System.out.println("Enter amount to deposit :");
	                    System.out.println("......................");
	                    double depositAmount=sc.nextDouble();
	                    deposit(depositAmount);
	                    System.out.println("\n");
	                    break;
	                case '3':
	                    System.out.println("......................");
	                    System.out.println("Enter amount to Withdraw :");
	                    System.out.println("......................");
	                    double withdrawAmount=sc.nextDouble();
	                    withdraw(withdrawAmount);
	                    System.out.println("\n");
	                    break;
	                case '4':
	                    System.out.println("......................");
	                    System.out.println("Previous Transaction:");
	                    getPreviousTransaction();
	                    System.out.println("......................");
	                    System.out.println("\n");
	                    break;

	                case '5':
	                    System.out.println("......................");
	                    break;
	                default:
	                    System.out.println("Choose a correct option to proceed");
	                    break;
	            }

	        }while(option!='5');

	        System.out.println("Thank you for using our banking services & Welcome again.....");
	    }

	}


