package sampleprograms;

public class Sample {
	public static void main(String[] args) {
		int num=2;
		long num1=23l;
		float num3=3.4f;
		double num4=4.5d;
		char initial='a';
		String name="Abi";
	System.out.println(num+" "+num1+" "+num3+" "+" "+num4+" "+initial+" "+name);	
	}
		

		


}
