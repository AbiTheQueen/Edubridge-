package sampleprograms;
import java.util.Scanner;

public class Samaple2 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int num=Integer.valueOf(args[0]);
		long num1=Long.valueOf(args[1]);
		float num3=Float.valueOf(args[2]);
		double num4=Double.valueOf(args[3]);
	    boolean condition=Boolean.valueOf(args[4]);
		System.out.println(num+" "+num1+" "+num3+" "+num4+" "+condition);
	}

}
